# Problems

[Browse the proof index](../README.md#proof-index) · [Complete upload checklist](../docs/upload-inventory.md#materials-still-to-upload)

Manuscripts are available for **Erdős 14, 96, 108, 196, 272, 354 (i), and 944**, and **Green 15, 40 (f(2)), 47, and 51 (1/2)**.

Use `erdos-<number>/` and `green-<number>/` to distinguish the collections. Multiple parts stay in one problem folder: Erdős 14 includes the unified PDF and both Lean files. The Green 47 package addresses exact containment, and Green 51 covers the one-half-density question.

The full list supplied by the author has 12 entries. Erdős 18 is awaiting both PDF and Lean files; Green 40 (f(2)) is awaiting its Lean source. All other listed problems have both a PDF and a Lean counterpart. Erdős 108 also has a [source correspondence note](erdos-108/lean/README.md#manuscript-correspondence) to resolve. These items are tracked in the inventory.

See [Adding and updating a proof](../CONTRIBUTING.md) and the [problem template](../templates/problem/) for new uploads.
