from pathlib import Path
import json


folder = Path(__file__).resolve().parent
combined = {}
for shard_path in sorted(folder.glob("D-equal-gaps-[0-9][0-9].json")):
    shard = json.loads(shard_path.read_bytes())
    for model_name, model in shard.items():
        if model_name not in combined:
            combined[model_name] = model
        else:
            combined[model_name]["rows"].extend(model["rows"])

output_path = folder / "D-equal-gaps.json"
with output_path.open("xb") as output:
    data = json.dumps(combined, separators=(",", ":"), ensure_ascii=True) + "\n"
    output.write(data.encode("utf-8"))
print(output_path)
